﻿# ImageLabeler

ImageLabeler is a small tool I'm writing for my comic bubble detection and translation system.

It uses DLib image set label format.